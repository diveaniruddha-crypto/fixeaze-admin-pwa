import 'dart:convert';
import 'dart:js_interop';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import 'admin_widgets.dart';

@JS('fixeazePush.supported')
external JSBoolean _supported();

@JS('fixeazePush.permission')
external JSString _permission();

@JS('fixeazePush.play')
external void _play(JSString kind);

@JS('fixeazePush.enable')
external JSPromise<JSString> _enable(JSString vapid, JSBoolean ask);

/// Phone notifications for admins (Web Push). The sending side is the Edge Function "push".
class PushService {
  /// Public half of the notification key. The private half lives only in Supabase.
  static const vapidPublicKey =
      'BEW1X9dQ9to-7tUbirikRmuVdkc8fxNaJcEiYCEEQTOyK0AXKTBcCXV4bqpgUha03fT7M4-NZwIYWcmGj1sI_ns';

  static bool get supported {
    try {
      return _supported().toDart;
    } catch (_) {
      return false;
    }
  }

  /// granted / denied / default / unsupported
  static String get permission {
    try {
      return _permission().toDart;
    } catch (_) {
      return 'unsupported';
    }
  }

  static void playSound(String kind) {
    try {
      _play(kind.toJS);
    } catch (_) {}
  }

  /// Turns notifications on for this phone and saves it. Returns an error text, or null when done.
  static Future<String?> enable({bool ask = true}) async {
    try {
      final text = (await _enable(vapidPublicKey.toJS, ask.toJS).toDart).toDart;
      if (text.isEmpty) return null;
      final json = (jsonDecode(text) as Map).cast<String, dynamic>();
      final keys = (json['keys'] as Map).cast<String, dynamic>();
      await supabase.from('admin_push_subscriptions').upsert({
        'admin_id': supabase.auth.currentUser!.id,
        'endpoint': json['endpoint'],
        'p256dh': keys['p256dh'],
        'auth': keys['auth'],
        'user_agent': 'web',
      }, onConflict: 'endpoint');
      return null;
    } on PostgrestException catch (e) {
      return e.message;
    } catch (e) {
      final m = '$e';
      return m.contains('Error:') ? m.split('Error:').last.trim() : m;
    }
  }

  /// Quietly re-registers when permission was already given.
  static Future<void> refreshIfGranted() async {
    if (permission == 'granted') await enable(ask: false);
  }
}

// ============================================================== PAGE

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  bool _busy = false;
  String? _msg;
  bool _ok = false;

  Future<void> _turnOn() async {
    setState(() {
      _busy = true;
      _msg = null;
    });
    final err = await PushService.enable();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _ok = err == null;
      _msg = err ?? 'Notifications are on for this phone.';
    });
  }

  Future<void> _test() async {
    setState(() => _busy = true);
    try {
      await supabase.rpc('admin_push_test');
      if (!mounted) return;
      setState(() => _msg = 'Test sent. It should arrive in a few seconds.');
      _ok = true;
    } catch (e) {
      if (!mounted) return;
      _ok = false;
      _msg = e is PostgrestException ? e.message : '$e';
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final perm = PushService.permission;
    final on = perm == 'granted';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'Phone notifications',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
              on
                  ? const Pill('Allowed on this device', kOk)
                  : perm == 'denied'
                      ? const Pill('Blocked in settings', kBad)
                      : perm == 'unsupported'
                          ? const Pill('Not supported here', kWarn)
                          : const Pill('Not turned on', kWarn),
            ]),
            const SizedBox(height: 10),
            const Muted('Install the admin app on your home screen first (browser menu > Install app / Add to Home screen), '
                'open it, then tap the button below on every phone you want alerts on.'),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 10, children: [
              FilledButton.icon(
                style: FilledButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: _busy ? null : _turnOn,
                icon: const Icon(Icons.notifications_active_outlined),
                label: Text(on ? 'Refresh notifications' : 'Turn on notifications'),
              ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: _busy ? null : _test,
                icon: const Icon(Icons.send_outlined),
                label: const Text('Send a test'),
              ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: () => PushService.playSound('alert'),
                icon: const Icon(Icons.volume_up_outlined),
                label: const Text('Hear alert sound'),
              ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                onPressed: () => PushService.playSound('chat'),
                icon: const Icon(Icons.chat_bubble_outline),
                label: const Text('Hear chat sound'),
              ),
            ]),
            if (_msg != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_msg!, style: TextStyle(color: _ok ? kOk : kBad, fontWeight: FontWeight.w600)),
              ),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionCard(
          title: 'You will be told about',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SOS alerts'),
            Text('New bookings'),
            Text('Bookings nobody accepted in 30 minutes (OTC)'),
            Text('New support tickets and customer replies'),
            Text('Technicians waiting for approval'),
            Text('Technician payments pending'),
            Text('Messages in Admin chat (group and personal)'),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionCard(
          title: 'About the sounds',
          child: Muted('While the app is open you hear the alert chime for everything, and a different soft pop for chat. '
              'When the app is closed the phone itself plays its normal notification sound (a website cannot choose it), '
              'so chat is told apart by a short buzz and everything else by a long buzz.'),
        ),
      ],
    );
  }
}

import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' show PdfDocument, PdfTextExtractor;
import 'package:url_launcher/url_launcher.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

const _outcomes = <String, String>{
  'interested': 'Interested',
  'not_interested': 'Not interested',
  'follow_up': 'Follow-up required',
  'meeting': 'Meeting required',
  'no_answer': 'No answer',
  'note': 'Just a note (no call)',
};

Color _outcomeColor(String o) {
  switch (o) {
    case 'interested':
      return kOk;
    case 'not_interested':
      return kBad;
    case 'follow_up':
      return kWarn;
    case 'meeting':
      return kInfo;
    default:
      return Colors.grey;
  }
}

Widget _statusPill(String st) => st == 'new'
    ? const Pill('New', Colors.grey)
    : Pill(_outcomes[st] ?? st, _outcomeColor(st));

// ============================================================== parsing helpers

String? _normPhone(String raw) {
  var d = raw.replaceAll(RegExp(r'\D'), '');
  if (d.length == 12 && d.startsWith('91')) d = d.substring(2);
  if (d.length == 11 && d.startsWith('0')) d = d.substring(1);
  return d.length == 10 ? d : null;
}

/// Reads the cells of an .xlsx file (all sheets) without extra libraries.
List<List<String>> _xlsxRows(List<int> bytes) {
  final zip = ZipDecoder().decodeBytes(bytes);
  String? read(String name) {
    for (final f in zip.files) {
      if (f.isFile && f.name == name) return utf8.decode(f.content as List<int>, allowMalformed: true);
    }
    return null;
  }

  String unesc(String x) => x
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAll('&amp;', '&');
  String texts(String x) =>
      unesc(RegExp(r'<t\b[^>]*>(.*?)</t>', dotAll: true).allMatches(x).map((t) => t.group(1)!).join());

  final shared = <String>[];
  final ss = read('xl/sharedStrings.xml');
  if (ss != null) {
    for (final m in RegExp(r'<si\b[^>]*>(.*?)</si>', dotAll: true).allMatches(ss)) {
      shared.add(texts(m.group(1)!));
    }
  }
  final names = [
    for (final f in zip.files)
      if (f.isFile && RegExp(r'^xl/worksheets/sheet\d+\.xml$').hasMatch(f.name)) f.name
  ]..sort();
  final out = <List<String>>[];
  for (final name in names) {
    final xml = read(name) ?? '';
    for (final rm in RegExp(r'<row\b[^>]*>(.*?)</row>', dotAll: true).allMatches(xml)) {
      final row = <String>[];
      for (final cm in RegExp(r'<c\b([^>]*?)(?:/>|>(.*?)</c>)', dotAll: true).allMatches(rm.group(1)!)) {
        final attrs = cm.group(1) ?? '';
        final inner = cm.group(2) ?? '';
        final ref = RegExp(r'\br="([A-Z]+)\d+"').firstMatch(attrs)?.group(1);
        final type = RegExp(r'\bt="(\w+)"').firstMatch(attrs)?.group(1);
        var idx = row.length;
        if (ref != null) {
          idx = 0;
          for (final ch in ref.codeUnits) {
            idx = idx * 26 + (ch - 64);
          }
          idx -= 1;
        }
        var val = '';
        if (type == 'inlineStr') {
          val = texts(inner);
        } else {
          final v = RegExp(r'<v>(.*?)</v>', dotAll: true).firstMatch(inner)?.group(1) ?? '';
          if (type == 's') {
            final i = int.tryParse(v);
            val = i != null && i < shared.length ? shared[i] : '';
          } else {
            val = unesc(v);
            final d = double.tryParse(val);
            if (d != null && d == d.roundToDouble() && d.abs() < 1e15) val = d.toInt().toString();
          }
        }
        while (row.length < idx) {
          row.add('');
        }
        if (row.length == idx) {
          row.add(val.trim());
        } else {
          row[idx] = val.trim();
        }
      }
      out.add(row);
    }
  }
  return out;
}

class _Lead {
  String name;
  String phone;
  String address;
  String city;
  String pincode;
  _Lead(this.name, this.phone, this.address, this.city, this.pincode);
}

List<List<String>> _parseCsv(String text) {
  final rows = <List<String>>[];
  var row = <String>[];
  final cur = StringBuffer();
  var quoted = false;
  for (var i = 0; i < text.length; i++) {
    final c = text[i];
    if (quoted) {
      if (c == '"') {
        if (i + 1 < text.length && text[i + 1] == '"') {
          cur.write('"');
          i++;
        } else {
          quoted = false;
        }
      } else {
        cur.write(c);
      }
    } else if (c == '"') {
      quoted = true;
    } else if (c == ',' || c == ';' || c == '\t') {
      row.add(cur.toString().trim());
      cur.clear();
    } else if (c == '\n' || c == '\r') {
      if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++;
      row.add(cur.toString().trim());
      cur.clear();
      if (row.any((e) => e.isNotEmpty)) rows.add(row);
      row = <String>[];
    } else {
      cur.write(c);
    }
  }
  row.add(cur.toString().trim());
  if (row.any((e) => e.isNotEmpty)) rows.add(row);
  return rows;
}

/// Table rows (CSV or Excel) -> leads. Uses the header row when it has recognisable names.
List<_Lead> _fromTable(List<List<String>> rows) {
  if (rows.isEmpty) return [];
  int find(List<String> head, List<String> keys) {
    for (var i = 0; i < head.length; i++) {
      final h = head[i].toLowerCase();
      if (keys.any((k) => h.contains(k))) return i;
    }
    return -1;
  }

  final head = rows.first;
  var iName = find(head, ['name']);
  var iPhone = find(head, ['phone', 'mobile', 'contact', 'number', 'mob']);
  var iAddr = find(head, ['address', 'location', 'area']);
  var iCity = find(head, ['city', 'town', 'district']);
  var iPin = find(head, ['pin', 'zip']);
  var data = rows;
  if (iName >= 0 && iPhone >= 0) {
    data = rows.sublist(1);
  } else {
    // No header: find the phone column, the rest follow in order.
    final width = rows.map((r) => r.length).fold<int>(0, (a, b) => a > b ? a : b);
    var best = -1;
    var bestN = 0;
    for (var c = 0; c < width; c++) {
      final n = rows.where((r) => c < r.length && _normPhone(r[c]) != null).length;
      if (n > bestN) {
        bestN = n;
        best = c;
      }
    }
    iPhone = best;
    final others = [for (var c = 0; c < width; c++) if (c != best) c];
    iName = others.isNotEmpty ? others[0] : -1;
    iAddr = others.length > 1 ? others[1] : -1;
    iCity = others.length > 2 ? others[2] : -1;
    iPin = others.length > 3 ? others[3] : -1;
  }
  if (iPhone < 0) return [];
  String at(List<String> r, int i) => i >= 0 && i < r.length ? r[i].trim() : '';
  final out = <_Lead>[];
  for (final r in data) {
    final p = _normPhone(at(r, iPhone));
    if (p == null) continue;
    var pin = at(r, iPin).replaceAll(RegExp(r'\D'), '');
    if (pin.length != 6) pin = RegExp(r'\b[1-9]\d{5}\b').firstMatch(at(r, iAddr))?.group(0) ?? '';
    final name = at(r, iName);
    out.add(_Lead(name.isEmpty ? 'Unnamed' : name, p, at(r, iAddr), at(r, iCity), pin));
  }
  return out;
}

/// Free text (PDF or pasted): one lead per line that contains a mobile number.
List<_Lead> _fromText(String text) {
  final phoneRe = RegExp(r'(?:\+?91[\s-]?)?[6-9](?:[\s-]?\d){9}');
  final out = <_Lead>[];
  for (final raw in text.split(RegExp(r'[\r\n]+'))) {
    final line = raw.trim();
    final m = phoneRe.firstMatch(line);
    if (m == null) continue;
    final p = _normPhone(m.group(0)!);
    if (p == null) continue;
    var before = line.substring(0, m.start).replaceFirst(RegExp(r'^\d+[\.\)]\s*'), '');
    var after = line.substring(m.end);
    final pin = RegExp(r'\b[1-9]\d{5}\b').firstMatch(after)?.group(0) ?? '';
    if (pin.isNotEmpty) after = after.replaceFirst(pin, '');
    String clean(String x) => x.replaceAll(RegExp(r'^[\s,:;\-|]+|[\s,:;\-|]+$'), '');
    before = clean(before);
    out.add(_Lead(before.isEmpty ? 'Unnamed' : before, p, clean(after), '', pin));
  }
  return out;
}

// ============================================================== PAGE

class ContactsPage extends StatefulWidget {
  const ContactsPage({super.key});
  @override
  State<ContactsPage> createState() => _ContactsPageState();
}

class _ContactsPageState extends State<ContactsPage> {
  String _kind = 'all';
  String _status = 'all';
  String _by = 'all';
  String _city = 'all';
  String _sort = 'new';
  int _limit = 100;
  final _q = TextEditingController();
  final _pin = TextEditingController();

  @override
  void initState() {
    super.initState();
    _s.addListener(_changed);
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _s.removeListener(_changed);
    _q.dispose();
    _pin.dispose();
    super.dispose();
  }

  Rec? _last(String id) {
    for (final c in _s.calls) {
      if ('${c['contact_id']}' == id && c['outcome'] != 'note') return c;
    }
    return null;
  }

  Future<void> _call(Rec c) async {
    try {
      await launchUrl(Uri.parse('tel:+91${c['phone']}'));
    } catch (_) {}
    if (!mounted) return;
    await showDialog<void>(context: context, builder: (_) => _LogDialog(contact: c, afterCall: true));
  }

  Future<void> _delete(Rec c) async {
    final ok = await confirmBox(
        context, 'Delete ${c['name']} (${c['phone']}) and all their call history? This cannot be undone.',
        yes: 'Delete');
    if (!ok) return;
    final err = await _s.contactDelete('${c['id']}', '${c['name']} ${c['phone']}');
    if (mounted) report(context, err, 'Deleted');
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final q = _q.text.trim().toLowerCase();
    final pin = _pin.text.trim();
    final cities = <String>{
      for (final c in s.contacts)
        if ('${c['city'] ?? ''}'.trim().isNotEmpty) '${c['city']}'.trim(),
    }.toList()
      ..sort();
    final adders = <String>{for (final c in s.contacts) if (c['added_by'] != null) '${c['added_by']}'}.toList();

    final rows = s.contacts.where((c) {
      if (_kind != 'all' && c['kind'] != _kind) return false;
      if (_status != 'all' && c['status'] != _status) return false;
      if (_by != 'all' && '${c['added_by']}' != _by) return false;
      if (_city != 'all' && '${c['city'] ?? ''}'.trim() != _city) return false;
      if (pin.isNotEmpty && !'${c['pincode'] ?? ''}'.startsWith(pin)) return false;
      if (q.isNotEmpty) {
        final hay = '${c['name']} ${c['phone']} ${c['address'] ?? ''} ${c['city'] ?? ''} ${c['pincode'] ?? ''}'.toLowerCase();
        if (!hay.contains(q)) return false;
      }
      return true;
    }).toList();

    int cmp(String a, String b) => a.toLowerCase().compareTo(b.toLowerCase());
    switch (_sort) {
      case 'name':
        rows.sort((a, b) => cmp('${a['name']}', '${b['name']}'));
        break;
      case 'pincode':
        rows.sort((a, b) {
          final x = '${a['pincode'] ?? ''}', y = '${b['pincode'] ?? ''}';
          if (x.isEmpty != y.isEmpty) return x.isEmpty ? 1 : -1;
          return x.compareTo(y);
        });
        break;
      case 'city':
        rows.sort((a, b) {
          final x = '${a['city'] ?? ''}', y = '${b['city'] ?? ''}';
          if (x.isEmpty != y.isEmpty) return x.isEmpty ? 1 : -1;
          return cmp(x, y);
        });
        break;
      case 'called':
        rows.sort((a, b) => '${a['last_called_at'] ?? ''}'.compareTo('${b['last_called_at'] ?? ''}'));
        break;
    }

    int count(String st) => s.contacts.where((c) => c['status'] == st).length;
    final shown = rows.take(_limit).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (s.errors['contacts'] != null)
          NoticeBanner('Contacts tables are missing. Run sql/v2_part16_contacts.sql in Supabase. (${s.errors['contacts']})',
              color: kBad),
        TileGrid([
          StatTile('Total contacts', '${s.contacts.length}'),
          StatTile('Not called yet', '${count('new')}'),
          StatTile('Interested', '${count('interested')}'),
          StatTile('Follow-up / meeting', '${count('follow_up') + count('meeting')}',
              alert: count('follow_up') + count('meeting') > 0),
        ]),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size(0, 42)),
            onPressed: () => showDialog<void>(context: context, builder: (_) => const _AddDialog()),
            icon: const Icon(Icons.person_add_alt),
            label: const Text('Add contact'),
          ),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(minimumSize: const Size(0, 42)),
            onPressed: () => showDialog<void>(context: context, builder: (_) => const _ImportDialog()),
            icon: const Icon(Icons.upload_file),
            label: const Text('Import PDF / Excel / CSV'),
          ),
          CsvButton(
            label: 'Download list (CSV)',
            name: 'contacts',
            headers: () => ['Type', 'Name', 'Phone', 'Address', 'City', 'Pincode', 'Added by', 'Status', 'Last call', 'Added on'],
            rows: () => [
              for (final c in rows)
                [c['kind'], c['name'], c['phone'], c['address'] ?? '', c['city'] ?? '', c['pincode'] ?? '',
                  s.nameOf(c['added_by']), c['status'], fdt(c['last_called_at']), fdt(c['created_at'])],
            ],
          ),
        ]),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in const {'all': 'All', 'new': 'New', 'interested': 'Interested', 'not_interested': 'Not interested', 'follow_up': 'Follow-up', 'meeting': 'Meeting'}.entries)
            ChoiceChip(
              label: Text(e.value),
              selected: _status == e.key,
              onSelected: (_) => setState(() {
                _status = e.key;
                _limit = 100;
              }),
            ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 12, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          SizedBox(
            width: 240,
            child: TextField(
              controller: _q,
              onChanged: (_) => setState(() => _limit = 100),
              decoration: const InputDecoration(
                  isDense: true, prefixIcon: Icon(Icons.search), hintText: 'Name, phone, address'),
            ),
          ),
          SizedBox(
            width: 130,
            child: TextField(
              controller: _pin,
              keyboardType: TextInputType.number,
              onChanged: (_) => setState(() => _limit = 100),
              decoration: const InputDecoration(isDense: true, hintText: 'Pincode'),
            ),
          ),
          DropdownButton<String>(
            value: _kind,
            items: const [
              DropdownMenuItem(value: 'all', child: Text('Technicians + customers')),
              DropdownMenuItem(value: 'technician', child: Text('Technicians')),
              DropdownMenuItem(value: 'customer', child: Text('Customers')),
            ],
            onChanged: (v) => setState(() => _kind = v ?? 'all'),
          ),
          DropdownButton<String>(
            value: cities.contains(_city) ? _city : 'all',
            items: [
              const DropdownMenuItem(value: 'all', child: Text('All cities')),
              for (final c in cities) DropdownMenuItem(value: c, child: Text(c)),
            ],
            onChanged: (v) => setState(() => _city = v ?? 'all'),
          ),
          DropdownButton<String>(
            value: adders.contains(_by) ? _by : 'all',
            items: [
              const DropdownMenuItem(value: 'all', child: Text('Added by anyone')),
              for (final a in adders) DropdownMenuItem(value: a, child: Text('Added by ${s.nameOf(a)}')),
            ],
            onChanged: (v) => setState(() => _by = v ?? 'all'),
          ),
          DropdownButton<String>(
            value: _sort,
            items: const [
              DropdownMenuItem(value: 'new', child: Text('Sort: newest first')),
              DropdownMenuItem(value: 'pincode', child: Text('Sort: pincode')),
              DropdownMenuItem(value: 'city', child: Text('Sort: city')),
              DropdownMenuItem(value: 'name', child: Text('Sort: name')),
              DropdownMenuItem(value: 'called', child: Text('Sort: not called / oldest call first')),
            ],
            onChanged: (v) => setState(() => _sort = v ?? 'new'),
          ),
        ]),
        const SizedBox(height: 10),
        Text('${rows.length} contact${rows.length == 1 ? '' : 's'}', style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        AdminTable(
          columns: const ['Name', 'Phone', 'City / PIN', 'Address', 'Added by', 'Status', 'Last call', ''],
          empty: 'No contacts yet. Tap Add contact or Import.',
          rows: [
            for (final c in shown)
              () {
                final id = '${c['id']}';
                final last = _last(id);
                final n = s.calls.where((x) => '${x['contact_id']}' == id && x['outcome'] != 'note').length;
                return <Widget>[
                  TwoLine('${c['name']}', c['kind'] == 'customer' ? 'Customer' : 'Technician'),
                  SelectableText('${c['phone']}'),
                  TwoLine('${c['city'] ?? ''}', '${c['pincode'] ?? ''}'),
                  SizedBox(width: 200, child: Text('${c['address'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis)),
                  TwoLine(s.nameOf(c['added_by']), fday(c['created_at'])),
                  _statusPill('${c['status']}'),
                  last == null ? const Muted('Never') : TwoLine(ago(last['created_at']), '$n call${n == 1 ? '' : 's'}'),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    FilledButton.icon(
                      style: FilledButton.styleFrom(minimumSize: const Size(0, 38)),
                      onPressed: () => _call(c),
                      icon: const Icon(Icons.call, size: 16),
                      label: const Text('Call'),
                    ),
                    const SizedBox(width: 6),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                      onPressed: () => showDialog<void>(context: context, builder: (_) => _HistoryDialog(contact: c)),
                      child: const Text('History'),
                    ),
                    IconButton(
                      tooltip: 'Delete',
                      icon: const Icon(Icons.delete_outline, color: kBad),
                      onPressed: () => _delete(c),
                    ),
                  ]),
                ];
              }(),
          ],
        ),
        if (rows.length > shown.length)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Center(
              child: OutlinedButton(
                onPressed: () => setState(() => _limit += 100),
                child: Text('Show more (${rows.length - shown.length} left)'),
              ),
            ),
          ),
      ],
    );
  }
}

// ============================================================== ADD ONE

class _AddDialog extends StatefulWidget {
  const _AddDialog();
  @override
  State<_AddDialog> createState() => _AddDialogState();
}

class _AddDialogState extends State<_AddDialog> {
  String _kind = 'technician';
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _addr = TextEditingController();
  final _city = TextEditingController();
  final _pin = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _addr.dispose();
    _city.dispose();
    _pin.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final p = _phone.text.trim().isEmpty ? null : _normPhone(_phone.text);
    if (_name.text.trim().isEmpty || p == null) {
      toast(context, 'Enter a name and a 10 digit mobile number', error: true);
      return;
    }
    if (_s.contacts.any((c) => c['phone'] == p && c['kind'] == _kind)) {
      toast(context, 'This number is already in your list', error: true);
      return;
    }
    setState(() => _busy = true);
    final err = await _s.contactsAdd([
      {
        'kind': _kind,
        'name': _name.text.trim(),
        'phone': p,
        'address': _addr.text.trim(),
        'city': _city.text.trim(),
        'pincode': _pin.text.trim(),
      }
    ]);
    if (!mounted) return;
    setState(() => _busy = false);
    report(context, err, 'Contact added');
    if (err == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add contact'),
      content: SizedBox(
        width: 440,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'technician', label: Text('Technician')),
                ButtonSegment(value: 'customer', label: Text('Customer')),
              ],
              selected: {_kind},
              onSelectionChanged: (v) => setState(() => _kind = v.first),
            ),
            const SizedBox(height: 10),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name')),
            const SizedBox(height: 8),
            TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Mobile number')),
            const SizedBox(height: 8),
            TextField(controller: _addr, maxLines: 2, decoration: const InputDecoration(labelText: 'Address')),
            const SizedBox(height: 8),
            TextField(controller: _city, decoration: const InputDecoration(labelText: 'City')),
            const SizedBox(height: 8),
            TextField(
                controller: _pin,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Pincode')),
            const SizedBox(height: 6),
            Muted('Added by ${_s.nameOf(_s.me?['id'], 'you')}'),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('Save')),
      ],
    );
  }
}

// ============================================================== IMPORT

class _ImportDialog extends StatefulWidget {
  const _ImportDialog();
  @override
  State<_ImportDialog> createState() => _ImportDialogState();
}

class _ImportDialogState extends State<_ImportDialog> {
  String _kind = 'technician';
  final _defCity = TextEditingController();
  List<_Lead> _leads = [];
  int _dupes = 0;
  String _file = '';
  String? _msg;
  bool _busy = false;
  final _paste = TextEditingController();

  @override
  void dispose() {
    _defCity.dispose();
    _paste.dispose();
    super.dispose();
  }

  void _setLeads(List<_Lead> all) {
    final have = <String>{
      for (final c in _s.contacts)
        if (c['kind'] == _kind) '${c['phone']}'
    };
    final seen = <String>{};
    final keep = <_Lead>[];
    var d = 0;
    for (final l in all) {
      if (have.contains(l.phone) || !seen.add(l.phone)) {
        d++;
      } else {
        keep.add(l);
      }
    }
    setState(() {
      _leads = keep;
      _dupes = d;
      _msg = keep.isEmpty && all.isEmpty ? 'No mobile numbers found in this file.' : null;
    });
  }

  Future<void> _pick() async {
    try {
      final r = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf', 'xlsx', 'csv', 'txt'],
        withData: true,
      );
      if (r == null || r.files.isEmpty) return;
      final f = r.files.first;
      final bytes = f.bytes;
      if (bytes == null) {
        setState(() => _msg = 'Could not read the file.');
        return;
      }
      setState(() {
        _busy = true;
        _file = f.name;
        _msg = null;
      });
      final ext = (f.extension ?? f.name.split('.').last).toLowerCase();
      List<_Lead> out;
      if (ext == 'pdf') {
        final doc = PdfDocument(inputBytes: bytes);
        final text = PdfTextExtractor(doc).extractText();
        doc.dispose();
        out = _fromText(text);
      } else if (ext == 'xlsx') {
        final rows = _xlsxRows(bytes);
        out = _fromTable(rows.where((r) => r.any((e) => e.isNotEmpty)).toList());
      } else if (ext == 'csv') {
        out = _fromTable(_parseCsv(utf8.decode(bytes, allowMalformed: true)));
      } else {
        out = _fromText(utf8.decode(bytes, allowMalformed: true));
      }
      _setLeads(out);
    } catch (e) {
      setState(() => _msg = 'Could not read this file: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    final city = _defCity.text.trim();
    final err = await _s.contactsAdd([
      for (final l in _leads)
        {
          'kind': _kind,
          'name': l.name,
          'phone': l.phone,
          'address': l.address,
          'city': l.city.isEmpty ? city : l.city,
          'pincode': l.pincode,
        }
    ]);
    if (!mounted) return;
    setState(() => _busy = false);
    report(context, err, '${_leads.length} contacts added');
    if (err == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Import contacts'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            const Muted('Excel / CSV: columns Name, Phone, Address, City, Pincode (a header row is best). '
                'PDF or text: one person per line with a mobile number. You can check the list before saving.'),
            const SizedBox(height: 10),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'technician', label: Text('Technicians')),
                ButtonSegment(value: 'customer', label: Text('Customers')),
              ],
              selected: {_kind},
              onSelectionChanged: (v) => setState(() => _kind = v.first),
            ),
            const SizedBox(height: 8),
            TextField(
                controller: _defCity,
                decoration: const InputDecoration(labelText: 'City for rows that have none (optional)')),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: _busy ? null : _pick,
              icon: const Icon(Icons.upload_file),
              label: Text(_file.isEmpty ? 'Choose file' : 'Choose another file'),
            ),
            if (_file.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Muted(_file)),
            const SizedBox(height: 10),
            const Text('Or paste text here:', style: TextStyle(fontSize: 12)),
            TextField(controller: _paste, maxLines: 3, decoration: const InputDecoration(border: OutlineInputBorder())),
            const SizedBox(height: 6),
            OutlinedButton(
              onPressed: () => _setLeads(_fromText(_paste.text)),
              child: const Text('Read pasted text'),
            ),
            if (_msg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_msg!, style: const TextStyle(color: kBad))),
            if (_leads.isNotEmpty || _dupes > 0) ...[
              const Divider(height: 24),
              Text('${_leads.length} new contacts found${_dupes > 0 ? ' ($_dupes already in your list or repeated, skipped)' : ''}',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              for (final l in _leads.take(8))
                Text('${l.name} · ${l.phone}${l.city.isNotEmpty ? ' · ${l.city}' : ''}${l.pincode.isNotEmpty ? ' · ${l.pincode}' : ''}',
                    style: const TextStyle(fontSize: 13)),
              if (_leads.length > 8) Muted('... and ${_leads.length - 8} more'),
            ],
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: _busy || _leads.isEmpty ? null : _save,
          child: Text('Save ${_leads.length} contacts'),
        ),
      ],
    );
  }
}

// ============================================================== LOG CALL / NOTE

class _LogDialog extends StatefulWidget {
  final Rec contact;
  final bool afterCall;
  const _LogDialog({required this.contact, required this.afterCall});
  @override
  State<_LogDialog> createState() => _LogDialogState();
}

class _LogDialogState extends State<_LogDialog> {
  late String _outcome = widget.afterCall ? 'interested' : 'note';
  final _note = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.contact;
    return AlertDialog(
      title: Text(widget.afterCall ? 'How was the call?' : 'Add a note'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text('${c['name']} · ${c['phone']}', style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            for (final e in _outcomes.entries)
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                value: e.key,
                groupValue: _outcome,
                onChanged: (v) => setState(() => _outcome = v ?? _outcome),
                title: Text(e.value),
              ),
            const SizedBox(height: 6),
            TextField(
              controller: _note,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Note (optional)', border: OutlineInputBorder()),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(
            onPressed: _busy ? null : () => Navigator.pop(context),
            child: Text(widget.afterCall ? 'Skip for now' : 'Cancel')),
        FilledButton(
          onPressed: _busy
              ? null
              : () async {
                  setState(() => _busy = true);
                  final err = await _s.callLog('${c['id']}', _outcome, _note.text.trim(), '${c['name']}');
                  if (!mounted) return;
                  setState(() => _busy = false);
                  report(context, err, 'Saved');
                  if (err == null) Navigator.pop(context);
                },
          child: const Text('Save'),
        ),
      ],
    );
  }
}

// ============================================================== HISTORY

class _HistoryDialog extends StatelessWidget {
  final Rec contact;
  const _HistoryDialog({required this.contact});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _s,
      builder: (context, _) {
        final id = '${contact['id']}';
        final c = _s.contacts.firstWhere((x) => '${x['id']}' == id, orElse: () => contact);
        final calls = _s.calls.where((x) => '${x['contact_id']}' == id).toList();
        return AlertDialog(
          title: Text('${c['name']}'),
          content: SizedBox(
            width: 480,
            child: SingleChildScrollView(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
                  SelectableText('${c['phone']}'),
                  _statusPill('${c['status']}'),
                ]),
                const SizedBox(height: 4),
                Muted([
                  c['kind'] == 'customer' ? 'Customer' : 'Technician',
                  '${c['address'] ?? ''}',
                  '${c['city'] ?? ''} ${c['pincode'] ?? ''}'.trim(),
                  'Added by ${_s.nameOf(c['added_by'])} on ${fday(c['created_at'])}',
                ].where((e) => e.isNotEmpty).join('\n')),
                const SectionTitle('Call history'),
                if (calls.isEmpty) const Muted('No calls yet.'),
                for (final x in calls)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
                        Pill(_outcomes['${x['outcome']}'] ?? '${x['outcome']}', _outcomeColor('${x['outcome']}')),
                        Muted('${fdt(x['created_at'])} · ${_s.nameOf(x['called_by'])}'),
                      ]),
                      if ('${x['note'] ?? ''}'.isNotEmpty)
                        Padding(padding: const EdgeInsets.only(top: 4), child: SelectableText('${x['note']}')),
                    ]),
                  ),
              ]),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => showDialog<void>(
                  context: context, builder: (_) => _LogDialog(contact: c, afterCall: false)),
              child: const Text('Add note'),
            ),
            TextButton(
              onPressed: () async {
                try {
                  await launchUrl(Uri.parse('tel:+91${c['phone']}'));
                } catch (_) {}
                if (!context.mounted) return;
                showDialog<void>(context: context, builder: (_) => _LogDialog(contact: c, afterCall: true));
              },
              child: const Text('Call'),
            ),
            FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
          ],
        );
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// One chat message bubble. [mine] puts it on the right.
class ChatBubble extends StatelessWidget {
  final String text;
  final String who;
  final DateTime? time;
  final bool mine;
  const ChatBubble({super.key, required this.text, required this.who, required this.time, required this.mine});

  @override
  Widget build(BuildContext context) {
    final bg = mine ? const Color(0xFFD7F0EC) : const Color(0xFFF1F1F1);
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 420),
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(who, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.black54)),
            const SizedBox(height: 2),
            SelectableText(text),
            const SizedBox(height: 2),
            Text(time == null ? '' : DateFormat('d MMM, h:mm a').format(time!.toLocal()),
                style: const TextStyle(fontSize: 10, color: Colors.black45)),
          ],
        ),
      ),
    );
  }
}

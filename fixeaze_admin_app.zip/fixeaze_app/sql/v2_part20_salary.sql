-- Part 20: Salary / weekly payouts. Safe to run more than once.
-- Needs part 11 (payments with commission) and part 8.

alter table public.technician_payments add column if not exists pay_on date;

create table if not exists public.technician_payouts (
  id uuid primary key default gen_random_uuid(),
  technician_id uuid not null references public.profiles(id) on delete cascade,
  period_from timestamptz,
  period_to timestamptz,
  jobs int not null default 0,
  amount numeric(10,2) not null default 0,
  reference text,
  note text,
  paid_by uuid,
  created_at timestamptz not null default now()
);
alter table public.technician_payouts enable row level security;
drop policy if exists "payouts read" on public.technician_payouts;
create policy "payouts read" on public.technician_payouts for select to authenticated
  using (technician_id = auth.uid() or public.is_admin());
grant select on public.technician_payouts to authenticated;

-- One summary message instead of one per job when paying a whole week
create or replace function public.on_payment_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.updated_at := now();
  if tg_op = 'UPDATE' and coalesce(current_setting('fixeaze.bulk', true), '') = '1' then
    if new.status = 'paid' then new.paid_at := coalesce(new.paid_at, now()); end if;
    return new;
  end if;
  if tg_op = 'UPDATE' and new.status is distinct from old.status then
    if new.status = 'paid' then
      new.paid_at := coalesce(new.paid_at, now());
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (new.technician_id, 'payment', 'Payment received',
              'Fixeaze has paid Rs ' || new.amount || ' for your job.'
              || coalesce(' Reference: ' || new.reference || '.', ''));
    elsif new.status = 'processing' then
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (new.technician_id, 'payment', 'Payment is being processed',
              'Your payment of Rs ' || new.amount || ' is being processed.');
    elsif new.status = 'failed' then
      insert into public.technician_notifications (technician_id, kind, title, body)
      values (new.technician_id, 'payment', 'Payment failed',
              'Your payment of Rs ' || new.amount || ' could not be completed.'
              || coalesce(' ' || new.note, ''));
    end if;
  elsif tg_op = 'UPDATE' and new.amount is distinct from old.amount then
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (new.technician_id, 'payment', 'Payment amount updated',
            'Your payment amount is now Rs ' || new.amount || '.');
  end if;
  return new;
end $$;

-- Set the payout date for the unpaid jobs of one technician (or everyone when p_technician is null)
create or replace function public.admin_schedule_payout(p_technician uuid, p_from timestamptz, p_to timestamptz, p_pay_on date)
returns int language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if p_pay_on is null then raise exception 'Choose a payment date'; end if;
  perform set_config('fixeaze.bulk', '1', true);
  for r in
    select technician_id, count(*) as jobs, sum(amount) as total
      from public.technician_payments
     where status in ('pending', 'processing') and amount > 0
       and created_at >= p_from and created_at < p_to
       and (p_technician is null or technician_id = p_technician)
     group by technician_id
  loop
    update public.technician_payments set pay_on = p_pay_on
     where technician_id = r.technician_id and status in ('pending', 'processing') and amount > 0
       and created_at >= p_from and created_at < p_to;
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (r.technician_id, 'payment', 'Payout date set',
            'Your payout of Rs ' || r.total || ' for ' || r.jobs || ' job(s) will be paid on '
            || to_char(p_pay_on, 'DD Mon YYYY') || '.');
    n := n + 1;
  end loop;
  return n;
end $$;
grant execute on function public.admin_schedule_payout(uuid, timestamptz, timestamptz, date) to authenticated;

-- Pay a whole period for one technician: marks every unpaid job in it as paid
create or replace function public.admin_pay_period(p_technician uuid, p_from timestamptz, p_to timestamptz,
                                                   p_reference text, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare jobs int; total numeric;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  select count(*), coalesce(sum(amount), 0) into jobs, total
    from public.technician_payments
   where technician_id = p_technician and status in ('pending', 'processing')
     and created_at >= p_from and created_at < p_to;
  if jobs = 0 then raise exception 'Nothing is waiting to be paid in this period'; end if;

  perform set_config('fixeaze.bulk', '1', true);
  update public.technician_payments
     set status = 'paid', paid_at = now(),
         reference = nullif(trim(coalesce(p_reference, '')), ''),
         note = coalesce(nullif(trim(coalesce(p_note, '')), ''), note)
   where technician_id = p_technician and status in ('pending', 'processing')
     and created_at >= p_from and created_at < p_to;

  insert into public.technician_payouts (technician_id, period_from, period_to, jobs, amount, reference, note, paid_by)
  values (p_technician, p_from, p_to, jobs, total, nullif(trim(coalesce(p_reference, '')), ''),
          nullif(trim(coalesce(p_note, '')), ''), auth.uid());

  insert into public.technician_notifications (technician_id, kind, title, body)
  values (p_technician, 'payment', 'Payment received',
          'Fixeaze has paid Rs ' || total || ' for ' || jobs || ' job(s).'
          || coalesce(' Reference: ' || nullif(trim(coalesce(p_reference, '')), '') || '.', ''));
end $$;
grant execute on function public.admin_pay_period(uuid, timestamptz, timestamptz, text, text) to authenticated;

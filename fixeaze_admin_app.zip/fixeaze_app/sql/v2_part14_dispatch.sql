-- Part 14: Dispatch dashboard (accept time, unassigned bookings, assign by admin, notes)
-- Safe to run more than once.

alter table public.bookings add column if not exists accepted_at timestamptz;

-- Fill accepted_at the moment a booking becomes accepted
create or replace function public.set_accepted_at()
returns trigger language plpgsql as $$
begin
  if new.status = 'accepted' and old.status is distinct from 'accepted' and new.accepted_at is null then
    new.accepted_at := now();
  end if;
  return new;
end $$;
drop trigger if exists trg_set_accepted_at on public.bookings;
create trigger trg_set_accepted_at before update on public.bookings
  for each row execute function public.set_accepted_at();

-- Old bookings: use last update time as a best guess
update public.bookings set accepted_at = coalesce(updated_at, created_at)
where accepted_at is null and technician_id is not null and status <> 'pending';

-- Guard must ignore accepted_at
create or replace function public.bookings_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare skip text[] := array['status','technician_id','completion_photos','updated_at','accepted_at'];
begin
  if public.is_admin() then return new; end if;
  if coalesce(current_setting('fixeaze.rpc', true), '') = '1' then return new; end if;

  if (to_jsonb(new) - skip) <> (to_jsonb(old) - skip) then
    raise exception 'Not allowed to change these booking fields';
  end if;

  if auth.uid() = old.customer_id then
    if old.status in ('pending','accepted') and old.job_stage is null and new.status = 'cancelled'
       and new.technician_id is not distinct from old.technician_id
       and new.completion_photos is not distinct from old.completion_photos then
      return new;
    end if;
    raise exception 'Customers can only cancel a booking before the technician arrives';
  end if;

  if old.status = 'pending' and old.technician_id is null
     and new.status = 'accepted' and new.technician_id = auth.uid()
     and public.can_take_job(old.service_id, old.lat, old.lng) then
    return new;
  end if;

  raise exception 'Not allowed';
end $$;

-- Notes from admin to a customer or a technician
create table if not exists public.booking_notes (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  to_role text not null check (to_role in ('customer','technician')),
  to_user uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_by uuid,
  created_at timestamptz not null default now()
);
alter table public.booking_notes enable row level security;
drop policy if exists "notes read" on public.booking_notes;
create policy "notes read" on public.booking_notes for select to authenticated
  using (to_user = auth.uid() or public.is_admin());
grant select on public.booking_notes to authenticated;

create or replace function public.admin_send_note(p_booking uuid, p_to_role text, p_body text)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings; target uuid;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  if coalesce(trim(p_body), '') = '' then raise exception 'Write a note first'; end if;
  select * into b from public.bookings where id = p_booking;
  if not found then raise exception 'Booking not found'; end if;
  if p_to_role = 'customer' then target := b.customer_id;
  elsif p_to_role = 'technician' then target := b.technician_id;
  else raise exception 'Choose customer or technician'; end if;
  if target is null then raise exception 'No technician is assigned to this booking yet'; end if;

  insert into public.booking_notes (booking_id, to_role, to_user, body, created_by)
  values (p_booking, p_to_role, target, trim(p_body), auth.uid());

  if p_to_role = 'technician' then
    insert into public.technician_notifications (technician_id, kind, title, body)
    values (target, 'note', 'Note from Fixeaze', trim(p_body));
  end if;
end $$;
grant execute on function public.admin_send_note(uuid, text, text) to authenticated;

create or replace function public.admin_assign_booking(p_booking uuid, p_technician uuid, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare b public.bookings;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  select * into b from public.bookings where id = p_booking for update;
  if not found then raise exception 'Booking not found'; end if;
  if b.status not in ('pending','accepted') or b.job_stage is not null then
    raise exception 'This booking can no longer be reassigned';
  end if;
  if not exists (select 1 from public.profiles where id = p_technician and role = 'technician' and approved = true) then
    raise exception 'Choose an approved technician';
  end if;

  perform set_config('fixeaze.rpc', '1', true);
  update public.bookings
     set technician_id = p_technician, status = 'accepted', accepted_at = now()
   where id = p_booking;

  insert into public.technician_notifications (technician_id, kind, title, body)
  values (p_technician, 'assigned', 'New job assigned by Fixeaze',
          coalesce(nullif(trim(p_note), ''), 'Open My jobs to see the details.'));
  if coalesce(trim(p_note), '') <> '' then
    insert into public.booking_notes (booking_id, to_role, to_user, body, created_by)
    values (p_booking, 'technician', p_technician, trim(p_note), auth.uid());
  end if;
  insert into public.booking_notes (booking_id, to_role, to_user, body, created_by)
  values (p_booking, 'customer', b.customer_id,
          'A Fixeaze technician has been assigned to your booking.', auth.uid());
end $$;
grant execute on function public.admin_assign_booking(uuid, uuid, text) to authenticated;

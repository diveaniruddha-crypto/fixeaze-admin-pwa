-- Part 17: personal (1-to-1) chats between admins. The group chat keeps working.
-- Safe to run more than once. Needs part 15 first.

alter table public.admin_chat add column if not exists to_user uuid references public.profiles(id) on delete cascade;
create index if not exists admin_chat_created on public.admin_chat(created_at desc);

drop policy if exists "achat read" on public.admin_chat;
create policy "achat read" on public.admin_chat for select to authenticated
  using (public.is_admin() and (to_user is null or sender_id = auth.uid() or to_user = auth.uid()));

drop policy if exists "achat insert" on public.admin_chat;
create policy "achat insert" on public.admin_chat for insert to authenticated
  with check (
    public.is_admin() and sender_id = auth.uid()
    and (to_user is null or exists (select 1 from public.profiles p where p.id = to_user and p.role = 'admin'))
  );

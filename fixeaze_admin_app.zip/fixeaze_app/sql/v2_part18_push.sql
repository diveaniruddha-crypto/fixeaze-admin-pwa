-- Part 18: push notifications for admins. Safe to run more than once.
-- Needs parts 11-17. Also deploy the Edge Function "push" (see the steps you were given).

create extension if not exists pg_net with schema extensions;
create extension if not exists pg_cron;

create table if not exists public.admin_push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid not null references public.profiles(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now()
);
alter table public.admin_push_subscriptions enable row level security;
drop policy if exists "push subs own" on public.admin_push_subscriptions;
create policy "push subs own" on public.admin_push_subscriptions for all to authenticated
  using (admin_id = auth.uid() and public.is_admin())
  with check (admin_id = auth.uid() and public.is_admin());
grant select, insert, update, delete on public.admin_push_subscriptions to authenticated;

-- where to send and the shared secret (nobody but the database can read this table)
create table if not exists public.push_config (key text primary key, value text not null);
alter table public.push_config enable row level security;
revoke all on public.push_config from anon, authenticated;
insert into public.push_config (key, value) values
  ('url', 'https://yujmqhihsfpnyiiluxcy.supabase.co/functions/v1/push'),
  ('secret', '9QBIXNqyYYVOcuXNjcZURZNk05BX37JT')
on conflict (key) do update set value = excluded.value;

create table if not exists public.otc_alerts (
  booking_id uuid primary key references public.bookings(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.otc_alerts enable row level security;
revoke all on public.otc_alerts from anon, authenticated;

-- Sends one notification to the admins (never blocks the thing that triggered it)
create or replace function public.push_admins(p_kind text, p_title text, p_body text,
                                              p_only uuid default null, p_skip uuid default null)
returns void language plpgsql security definer set search_path = public as $$
declare u text; sec text;
begin
  select value into u from public.push_config where key = 'url';
  select value into sec from public.push_config where key = 'secret';
  if u is null or sec is null then return; end if;
  perform net.http_post(
    url := u,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', sec),
    body := jsonb_build_object('kind', p_kind, 'title', p_title, 'body', left(coalesce(p_body, ''), 200),
                               'only', p_only, 'skip', p_skip));
exception when others then
  null;
end $$;
revoke execute on function public.push_admins(text, text, text, uuid, uuid) from public, anon, authenticated;

-- Button "Send test" in the admin app
create or replace function public.admin_push_test()
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  perform public.push_admins('test', 'Fixeaze test', 'Notifications are working on this phone.', auth.uid(), null);
end $$;
grant execute on function public.admin_push_test() to authenticated;

-- ---------- triggers ----------
create or replace function public.trg_push_sos() returns trigger language plpgsql security definer set search_path = public as $$
declare n text;
begin
  select name into n from public.profiles where id = new.technician_id;
  perform public.push_admins('sos', 'SOS ALERT', coalesce(n, 'A technician') || ' needs help. ' || coalesce(new.note, ''));
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_push_sos on public.sos_alerts;
create trigger trg_push_sos after insert on public.sos_alerts for each row execute function public.trg_push_sos();

create or replace function public.trg_push_booking() returns trigger language plpgsql security definer set search_path = public as $$
declare s text;
begin
  select name into s from public.services where id = new.service_id;
  perform public.push_admins('booking', 'New booking', coalesce(s, 'Service') || ' - ' || coalesce(new.address, ''));
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_push_booking on public.bookings;
create trigger trg_push_booking after insert on public.bookings for each row execute function public.trg_push_booking();

create or replace function public.trg_push_ticket() returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.push_admins('ticket', 'New support ticket #' || new.ticket_no, new.subject);
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_push_ticket on public.support_tickets;
create trigger trg_push_ticket after insert on public.support_tickets for each row execute function public.trg_push_ticket();

create or replace function public.trg_push_ticket_reply() returns trigger language plpgsql security definer set search_path = public as $$
declare tno bigint;
begin
  if new.sender_role = 'user'
     and (select count(*) from public.support_messages where ticket_id = new.ticket_id) > 1 then
    select ticket_no into tno from public.support_tickets where id = new.ticket_id;
    perform public.push_admins('ticket', 'Reply on ticket #' || tno, new.body);
  end if;
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_push_ticket_reply on public.support_messages;
create trigger trg_push_ticket_reply after insert on public.support_messages for each row execute function public.trg_push_ticket_reply();

create or replace function public.trg_push_kyc() returns trigger language plpgsql security definer set search_path = public as $$
declare n text;
begin
  select name into n from public.profiles where id = new.id;
  perform public.push_admins('approval', 'Technician waiting for approval', coalesce(n, 'A technician') || ' submitted documents.');
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_push_kyc on public.technician_kyc;
create trigger trg_push_kyc after insert on public.technician_kyc for each row execute function public.trg_push_kyc();

create or replace function public.trg_push_payment() returns trigger language plpgsql security definer set search_path = public as $$
declare n text;
begin
  select name into n from public.profiles where id = new.technician_id;
  perform public.push_admins('payment', 'Technician payment pending', coalesce(n, 'Technician') || ' - Rs ' || coalesce(new.amount::text, '0'));
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_push_payment on public.technician_payments;
create trigger trg_push_payment after insert on public.technician_payments for each row execute function public.trg_push_payment();

create or replace function public.trg_push_chat() returns trigger language plpgsql security definer set search_path = public as $$
declare n text;
begin
  select name into n from public.profiles where id = new.sender_id;
  perform public.push_admins('chat', coalesce(n, 'Admin') || case when new.to_user is null then ' (group)' else '' end,
                             new.body, new.to_user, new.sender_id);
  return new;
exception when others then return new;
end $$;
drop trigger if exists trg_push_chat on public.admin_chat;
create trigger trg_push_chat after insert on public.admin_chat for each row execute function public.trg_push_chat();

-- Booking nobody accepted in 30 minutes (checked every minute)
create or replace function public.check_otc() returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in
    select b.id, b.address, s.name as svc
      from public.bookings b left join public.services s on s.id = b.service_id
     where b.status = 'pending' and b.technician_id is null
       and b.created_at < now() - interval '30 minutes'
       and b.created_at > now() - interval '2 days'
       and not exists (select 1 from public.otc_alerts o where o.booking_id = b.id)
  loop
    insert into public.otc_alerts (booking_id) values (r.id) on conflict do nothing;
    perform public.push_admins('otc', 'Booking not accepted in 30 min',
                               coalesce(r.svc, 'Booking') || ' - ' || coalesce(r.address, '') || ' - assign a technician');
  end loop;
end $$;
revoke execute on function public.check_otc() from public, anon, authenticated;

do $$ begin perform cron.unschedule('fixeaze-otc'); exception when others then null; end $$;
select cron.schedule('fixeaze-otc', '* * * * *', 'select public.check_otc()');
